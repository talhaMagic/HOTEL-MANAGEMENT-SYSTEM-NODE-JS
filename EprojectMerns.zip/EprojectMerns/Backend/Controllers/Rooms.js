
const { Rooms } = require("../Modules/Room");

//HTTP GET
//API : http://localhost:5000/roompage

async function Roompage(req, res) {

    const Roomsalldata = await Rooms.find();
    return res.status(201).send(Roomsalldata);

}

//HTTP POST
//API : http://localhost:5000/roompagepost

async function Roompcreate(req, res) {
    try {
        const { roomnumber, roomtype, roomprice, roomstatus, roomdescription } = req.body;

        // Validate fields
        if (!roomnumber) {
            return res.status(400).send({ "ERROR": "ROOM NUMBER IS NOT FOUND" });
        }
        if (!roomtype) {
            return res.status(400).send({ "ERROR": "ROOM TYPE IS NOT FOUND" });
        }
        if (!roomprice) {
            return res.status(400).send({ "ERROR": "ROOM PRICE IS NOT FOUND" });
        }
        if (!roomstatus) {
            return res.status(400).send({ "ERROR": "ROOM STATUS IS NOT FOUND" });
        }
        if (!roomdescription) {
            return res.status(400).send({ "ERROR": "ROOM DESCRIPTION IS NOT FOUND" });
        }

        // Validate values
        const roomnumberregex = /^(100|[1-5][0-9]{2}|600)$/;
        const roompriceregex = /^[0-9]+$/;
        const roomstatusregex = /^(available|booked|occupied)$/;
        const roomdescriptionregex = /^[a-zA-Z0-9\s,.'-]{10,200}$/;

        // Validate inputs with regex
        if (!roomnumberregex.test(roomnumber)) {
            return res.status(400).send({ "ERROR": "ROOM NUMBER MUST BE BETWEEN 100 AND 600" });
        }
        if (!roompriceregex.test(roomprice)) {
            return res.status(400).send({ "ERROR": "ROOM PRICE MUST BE A NUMBER" });
        }
        if (!roomstatusregex.test(roomstatus)) {
            return res.status(400).send({ "ERROR": "ROOM STATUS MUST BE 'available', 'booked', or 'occupied'" });
        }
        if (!roomdescriptionregex.test(roomdescription)) {
            return res.status(400).send({ "ERROR": "ROOM DESCRIPTION MUST BE BETWEEN 10 AND 200 CHARACTERS" });
        }

        // Check if room number already exists in the database
        const existroom = await Rooms.findOne({ Room_number: roomnumber });
        if (existroom) {
            return res.status(400).send({ "ERROR": "ROOM NUMBER ALREADY EXISTS" });
        }


        // Create new room with the ObjectId from Roomtyp
        await Rooms.create({
            Room_number: roomnumber,
            Room_type: roomtype, // Use the ObjectId of the Roomtyp document
            Room_price: roomprice,
            Room_status: roomstatus,
            Room_description: roomdescription,
        });

        return res.status(201).send({ "SUCCESS": "ROOM PAGE POST SUCCESSFUL" });

    } catch (error) {
        console.error(error);
        return res.status(500).send({ "ERROR": "SERVER INTERNAL ERROR" });
    }
}

//HTTP DELETE
//API : http://localhost:5000/roomdelete

async function roomdeleterecord(req, res) {
    const roomdelete = req.params.id; await Rooms.deleteOne({ _id: roomdelete });
    return res.status(200).send({ "SUCESS": "ROOM DELETE RECORD SUCESS" });

}

 //HTTP GET
 // http://localhost:5000/roompage/67616af1645fdaac502d7c94

const roomtypesinglerecord = async (req, res) => {
    try {
        const { id } = req.params;

        const Roomtypesingle = await Rooms.findById(id).populate("Room_type", "type_name description base_price");

        if (!Roomtypesingle) {
            return res.status(404).json({ success: false, message: "Room type single is not found" });
        }

        return res.status(200).json({ success: true, data: Roomtypesingle });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Error fetching room type", error: error.message });
    }
};

//HTTP PUT
//API : http://localhost:5000/roompage/101

async function roomupadterecord(req, res) {

    try {

        const updateroomnumber = req.params.Room_number;
        const Roomdata = await Rooms.findOne({ Room_number: updateroomnumber });
        if (!Roomdata) {
            return res.status(404).send({ "ERROR": "ROOM IS NOT FOUND" });
        }

        const { roomnumber, roomtype, roomprice, roomstatus, roomdescription } = req.body;

        // Validate fields
        if (!roomnumber) {
            return res.status(400).send({ "ERROR": "ROOM NUMBER IS NOT FOUND" });
        }
        if (!roomtype) {
            return res.status(400).send({ "ERROR": "ROOM TYPE IS NOT FOUND" });
        }
        if (!roomprice) {
            return res.status(400).send({ "ERROR": "ROOM PRICE IS NOT FOUND" });
        }
        if (!roomstatus) {
            return res.status(400).send({ "ERROR": "ROOM STATUS IS NOT FOUND" });
        }
        if (!roomdescription) {
            return res.status(400).send({ "ERROR": "ROOM DESCRIPTION IS NOT FOUND" });
        }

        // Validate values
        const roomnumberregex = /^(100|[1-5][0-9]{2}|600)$/;
        const roompriceregex = /^[0-9]+$/;
        const roomstatusregex = /^(available|booked|occupied)$/;
        const roomdescriptionregex = /^[a-zA-Z0-9\s,.'-]{10,200}$/;

        // Validate inputs with regex
        if (!roomnumberregex.test(roomnumber)) {
            return res.status(400).send({ "ERROR": "ROOM NUMBER MUST BE BETWEEN 100 AND 600" });
        }
        if (!roompriceregex.test(roomprice)) {
            return res.status(400).send({ "ERROR": "ROOM PRICE MUST BE A NUMBER" });
        }
        if (!roomstatusregex.test(roomstatus)) {
            return res.status(400).send({ "ERROR": "ROOM STATUS MUST BE 'available', 'booked', or 'occupied'" });
        }
        if (!roomdescriptionregex.test(roomdescription)) {
            return res.status(400).send({ "ERROR": "ROOM DESCRIPTION MUST BE BETWEEN 10 AND 200 CHARACTERS" });
        }

        // Update Romms data
        const updateRoom = await Rooms.updateOne(
            { Room_number: updateroomnumber },
            {
                $set: {
                    Room_number: roomnumber.toLowerCase(),
                    Room_type: roomtype,
                    Room_price: roomprice,
                    Room_status: roomstatus,
                    Room_description: roomdescription,
                },
            }
        );

        if (updateRoom.matchedCount > 0) {
            console.log("Room updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "ROOM IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE ROOMS:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}


module.exports = { Roompage, Roompcreate, roomdeleterecord, roomupadterecord, roomtypesinglerecord}