
const {Role} = require("../Modules/Role");


//HTTP METHOD 
//API : http://localhost:5000/Roleget

async function Rolepage(req,res){

    const Allrolesget = await Role.find();
    return res.status(201).send(Allrolesget);

}

//HTTP METHOD POST
//API : http://localhost:5000/Rolepost

async function Rolecreate(req,res){

    const {rolename,rolestatus} = req.body;

    const rolenameregex = /^[A-Za-z]+$/;

    if(!rolenameregex.test(rolename)){return res.status(400).send({"error": "role name only characters"})}

    if(!rolename){return res.status(400).send({"error": "rolename is required"})}
    if(!rolestatus){return res.status(400).send({"error": "rolestatus is required"})}

     const rolerecord = await Role.find({
        RoleName:rolename.toLowerCase(),
     });

     if(rolerecord.length > 0){
        return res.status(400).send({"error": "rolename is already taken"})
     }
     
     await Role.create({
        RoleName: rolename.toLowerCase(),
        RoleStatus: rolestatus,
    });

    return res.status(201).send({"SUCESS":"ROLE CREATE IS SUCESS"});

}

//METHOD DELETE
// API : http://localhost:5000/Roleget/6752900906d5095a2c58624a  
//LAST ME ID LENE HE RECORD KE ROLE WALI

async function DeleteRoles(req, res) {

    const deleterole = req.params.id;
    await Role.deleteOne({_id: deleterole});

    return res.status(201).send({ "SUCESS": "DELETE ROLE IS SUCESS" });

}

//METHOD UPDATE
// API : http://localhost:5000/Roleget/6752900906d5095a2c58624a  
//LAST ME ID LENE HE RECORD KE ROLE WALI PHIR JSON FORMAT ME  

async function updateRoles(req, res) {

    const roles = req.params.id;

    const fetchrolename = await Role.findOne({ _id: roles });

    if (!fetchrolename) { return res.status(201).send({ "ERROR": "ROLE IS NOT FOUND CHECK" }) }

    const {rolename,rolestatus} = req.body;

    const rolenameregex = /^[A-Za-z]+$/;

    if(!rolenameregex.test(rolename)){return res.status(400).send({"error": "role name only characters"})}

    if(!rolename){return res.status(400).send({"ERROR": "ROLE NAME IS REQUIRED"})}
    if(!rolestatus){return res.status(400).send({"ERROR": "ROLESTATUS IS REQUIRED"})}

    await Role.updateOne(

        { _id: roles },
        {
            $set: {
                RoleName: rolename.toLowerCase(),
                RoleStatus: rolestatus,
            }
        }
    );

    return res.status(201).send({ "SUCESS": "ROLE UPADTE IS SUCESS" });

}


module.exports = {Rolepage,Rolecreate,DeleteRoles,updateRoles}