
const {Roomtyp} = require("../Modules/Roomtype");

//HTTP GET
//API : http://localhost:5000/roomtypeget

async function Roomtypepage(req,res){

   const Rolltypealldata = await Roomtyp.find();
   return  res.status(201).send(Rolltypealldata);

}

//HTTP POST
//API : http://localhost:5000/roomtypepost

async function Roomtypecreate(req,res){

   const {roomtype,roomdescription,roomprice} = req.body;

   if(!roomtype){

      return res.status(401).send({"ERROR": "ROOM TYPE IS NOT FOUND"});
   }

   if(!roomdescription){
      return res.status(404).send({"ERROR": "ROOM DESCRIPTION IS NOT FOUND"});
   }

   if(!roomprice){
      return res.status(404).send({"ERROR": "ROOM PRICE IS NOT FOUND"});
   }

   const roomtyperegex = /^(single|double|suite)$/;
   const roomdescriptregex = /^[a-zA-Z0-9\s,.'-]{10,100}$/;
   // const roompriceregex = /^\d{1,3}(?:,\d{3})*(?:\.\d{2})?$/;

   if(!roomtyperegex.test(roomtype)){
      return res.status(401).send({"ERROR":"ROOM TYPE IS ONLY SELECT single, double, suite "});
   }

   if(!roomdescriptregex.test(roomdescription)){
      return res.status(401).send({"ERROR":"ROOM DESCRIPTION ONLY 100 WORDS ONLY"});
   }

   // if(!roompriceregex.test(roomprice)){
   //    return res.status(401).send({"ERROR":"ROOM PRICE ONLY PKR CURRENCY"});
   // }
       
   const roomfinalexist = await Roomtyp.find({
      type_name: roomtype.toLowerCase(),
   });

   if(roomfinalexist.length> 0){

      return res.status(400).send({"ERROR": "ROOM NAME IS ALREADY EXIST"}); 
   }

   await Roomtyp.create({
      type_name:roomtype.toLowerCase(),
      description:roomdescription,
      base_price:roomprice,
   });


   return res.status(201).send({"SUCESS":"ROOM PAGE GET SUCESS"});

}

//HTTP POST
//API : http://localhost:5000/roomtypedelete/67581b47256f5b522187e3b2

  async function Deleteroomtypedata(req,res){

      const Roomtypedelete = req.params.id;
      await Roomtyp.deleteOne({_id: Roomtypedelete});
      return res.status(201).send({"SUCESS": "DELETE ROOM SUCESS"});

   }
   

//HTTP PUT
//API : http://localhost:5000/roomtypeupdate/67581b47256f5b522187e3b2

async function Updateroomtype(req, res) {
   try {
       const updateroomtypename = req.params.id;  // Use 'id' from the URL

       // Find the room type by the 'type_name' field (not '_id')
       const fetchdata = await Roomtyp.findOne({ type_name: updateroomtypename });

       if (!fetchdata) {
           return res.status(404).send({ "ERROR": "ROOM TYPE NOT FOUND" });
       }

       // Extract data from the request body
       const { roomtype, roomdescription, roomprice } = req.body;

       // Validate the required fields
       if (!roomtype) {
           return res.status(400).send({ "ERROR": "ROOM TYPE IS REQUIRED" });
       }

       if (!roomdescription) {
           return res.status(400).send({ "ERROR": "ROOM DESCRIPTION IS REQUIRED" });
       }

       if (!roomprice) {
           return res.status(400).send({ "ERROR": "ROOM PRICE IS REQUIRED" });
       }

       // Define regex to validate roomtype and roomdescription
       const roomtyperegex = /^(single|double|suite)$/;
       const roomdescriptregex = /^[a-zA-Z0-9\s,.'-]{10,100}$/;

       // Validate room type
       if (!roomtyperegex.test(roomtype)) {
           return res.status(400).send({ "ERROR": "ROOM TYPE SHOULD BE ONE OF 'single', 'double', 'suite'" });
       }

       // Validate room description
       if (!roomdescriptregex.test(roomdescription)) {
           return res.status(400).send({ "ERROR": "ROOM DESCRIPTION SHOULD BE BETWEEN 10 TO 100 CHARACTERS" });
       }

       // Update the room type data
       const updateroomtype = await Roomtyp.updateOne(
           { type_name: updateroomtypename },  
           {
               $set: {
                   type_name: roomtype.toLowerCase(),
                   description: roomdescription,
                   base_price: roomprice,
                   updated_at: Date.now(),  
               },
           }
       );

       if (updateroomtype.matchedCount > 0) {
           return res.status(200).send({ "SUCCESS": "ROOM TYPE UPDATED SUCCESSFULLY" });
       } else {
           return res.status(400).send({ "ERROR": "ROOM TYPE UPDATE FAILED" });
       }
   } catch (error) {
       console.error("ERROR UPDATE ROOMTYPE:", error);
       return res.status(500).send({ "ERROR": "INTERNAL SERVER ERROR" });
   }
}



module.exports = {Roomtypepage, Roomtypecreate, Deleteroomtypedata, Updateroomtype}