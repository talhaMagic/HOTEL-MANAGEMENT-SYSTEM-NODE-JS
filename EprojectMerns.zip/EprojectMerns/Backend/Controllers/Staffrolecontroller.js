
const { staffrole } = require("../Modules/StaffRole");

// HTTP GET
// API: http://localhost:5000/staffget
async function staffget(req, res) {

    const Staffalldata = await staffrole.find();
    return res.status(201).send(Staffalldata);

}

// HTTP POST
// API: http://localhost:5000/staffpost
async function staffcreate(req, res) {
    try {
        const { staffroles, status } = req.body;

        // Validate required fields
        if (!staffroles) {
            return res.status(400).send({ "ERROR": "STAFF ROLE IS NOT FOUND" });
        }
        if (!status) {
            return res.status(400).send({ "ERROR": "STATUS IS NOT FOUND" });
        }

        // Check if the staff role already exists
        const staffexist = await staffrole.findOne({ staff_Role: staffroles });
        if (staffexist) {
            return res.status(409).send({ "ERROR": "STAFF ROLE ALREADY EXISTS" });
        }

        // Create new staff entry
        await staffrole.create({
            staff_Role: staffroles,
            Status: status,
        });

        return res.status(201).send({ "SUCCESS": "STAFF POST CREATED" });

    } catch (error) {
        console.error("Error creating staff:", error.message);
        return res.status(500).send({ "ERROR": "SERVER INTERNAL ERROR" });
    }
}

//HTTP DELETE
//API : http://localhost:5000/staffdelete

async function staffrecorddelete(req, res) {
    const staffdelete = req.params.id; await staffrole.deleteOne({ _id: staffdelete });
    return res.status(200).send({ "SUCESS": "STAFF ROLE DELETE RECORD SUCESS" });

}

// HTTP PUT
// API: http://localhost:5000/staffupdate/admin
async function staffupdate(req, res) {
    try {
        const staffupdaterecord = req.params.staff_Role;

        const Staffdata = await staffrole.findOne({ staff_Role: staffupdaterecord });
        if (!Staffdata) {
            return res.status(404).send({ "ERROR": "STAFF IS NOT FOUND" });
        }

        const { staffroles, status } = req.body;

        // Validate required fields
        if (!staffroles) {
            return res.status(400).send({ "ERROR": "STAFF ROLE IS NOT FOUND" });
        }
        if (!status) {
            return res.status(400).send({ "ERROR": "STATUS IS NOT FOUND" });
        }

        const Updatestaffs = await staffrole.updateOne(
            { staff_Role: staffupdaterecord },
            {
                $set: {
                    staff_Role: staffroles,
                    Status: status,
                    updated_at: Date.now(),
                },
            }
        );

        if (Updatestaffs.matchedCount > 0) {
            console.log("Staff updated successfully");
            return res.status(200).send({ "SUCCESS": "STAFF UPDATED SUCCESSFULLY", data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "STAFF IS NOT FOUND" });
        }
    } catch (error) {
        console.error("Error updating staff:", error.message);
        return res.status(500).send({ "ERROR": "SERVER INTERNAL ERROR", details: error.message });
    }
}

module.exports = {staffcreate,staffupdate,staffget,staffrecorddelete}