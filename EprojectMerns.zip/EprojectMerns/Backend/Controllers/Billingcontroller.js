const Billing = require("../Modules/Billing"); // Correctly import the Billing model

//HTTP GET
//API : http://localhost:5000/Billingget

async function Billpage(req, res) {

  const Billalldata = await Billing.find();
  return res.status(201).send(Billalldata);

}

//HTTP POST
//API : http://localhost:5000/Billingpost

async function Billingcreate(req, res) {
  try {
    const { reservationid, billingamount, services, paymantstatus } = req.body;


    if (!reservationid || !billingamount || !services || !paymantstatus) {
      return res.status(400).send({ "ERROR": "All fields are required" });
    }

    const existingBilling = await Billing.findOne({ reservation_id: reservationid });
    if (existingBilling) {
      return res.status(400).send({ "ERROR": "Billing with this invoice ID already exists" });
    }

    const newBilling = await Billing.create({
      reservation_id: reservationid,
      billing_amount: billingamount,
      service: services,
      payment_status: paymantstatus,  // Fixed typo
    });

    return res.status(201).send({ "SUCCESS": "Billing record created", data: newBilling });
  } catch (error) {
    console.error("Error in Billingcreate:", error);
    return res.status(500).send({ "ERROR": "Server internal error" });
  }
}

//HTTP DELETE
//API : http://localhost:5000/Billindelte/

async function Billingdeleterecord(req, res) {
  const billdelete = req.params.id; await Billing.deleteOne({ _id: billdelete });
  return res.status(200).send({ "SUCESS": "Bill DELETE RECORD SUCESS" });
}


//HTTP PUT
//API : http://localhost:5000/Billingget/pending

async function Billingupadterecord(req, res) {

  try {

    const updatebilling = req.params.payment_status;
    const billingdata = await Billing.findOne({ payment_status: updatebilling });
    if (!billingdata) {
      return res.status(404).send({ "ERROR": "Billing IS NOT FOUND" });
    }

    const { reservationid, billingamount, services, paymantstatus } = req.body;

    if (!reservationid || !billingamount || !services || !paymantstatus) {
      return res.status(400).send({ "ERROR": "All fields are required" });
    }

    const updateBilling = await Billing.updateOne(
      { payment_status: updatebilling },
      {
        $set: {
          reservation_id: reservationid,
          billing_amount: billingamount,
          service: services,
          payment_status: paymantstatus,

        },
      }
    );

    if (updateBilling.matchedCount > 0) {
      console.log("Billing updated successfully");
      return res.send({ success: true, data: req.body });
  } else {
      return res.status(404).send({ "ERROR": "Billing IS NOT FOUND" });
  }


  } catch (error) {
    console.error("ERROR UPADTE Billing:", error);
    return res.status(500).send({ error: "Internal Server Error", details: error.message });
  }
}


// HTTP GET
// API : http://localhost:5000/Billingget/:id

const singlebillingrecord = async (req, res) => {
  try {
    const { id } = req.params;

    const singletypesingle = await Billing.findById(id)
          .populate({
            path: "reservation_id",
            select: "guest_id room_id staff_id check_in check_out status", 
            populate: [
              {
                path: "guest_id", 
                select: "UserName UserEmail UserPassword role created_at", 
                populate: {
                  path: "role", 
                  select: "RoleName RoleStatus" 
                }
              },
              {
                path: "room_id", 
                select: "Room_number Room_type Room_price Room_status Room_description"
              },
            ]
          });

    if (!singletypesingle) {
      return res.status(404).json({ success: false, message: "Billing single is not found" });
    }

    return res.status(200).json({ success: true, data: singletypesingle });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching Billing", error: error.message });
  }
};



module.exports = { Billingcreate, Billpage, Billingdeleterecord, Billingupadterecord,singlebillingrecord};
