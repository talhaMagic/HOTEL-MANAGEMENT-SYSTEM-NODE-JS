const { Audit } = require("../Modules/Auditlog");


// HTTP GET
// API : http://localhost:5000/auditget

async function auditpage(req, res) {

    const Auditalldata = await Audit.find();
    return res.status(201).send(Auditalldata);

}

// HTTP GET
// API : http://localhost:5000/auditget/67616da0645fdaac502d7ca7
async function auditsinglepage(req, res) {
    try {
        const AllAuditdata = await Audit.find()
            .populate({
                path: "Audit_guest",
                select: "UserName UserEmail UserPassword role staffrole",
                populate: {
                    path: "role", 
                    select: "RoleName RoleStatus", 
                },
            }); 

        return res.status(200).send(AllAuditdata);
    } catch (error) {
        console.error("Error fetching audit logs:", error.message);
        return res.status(500).send({ error: "Internal server error" });
    }
}


// HTTP POST
// API : http://localhost:5000/auditpost
async function auditcreate(req, res) {
    try {
        const { Action, Audit_guest, Time_stamp, Affectedentity, details } = req.body;

        if (!Action) return res.status(400).send({ error: "Action is required" });
        if (!Audit_guest) return res.status(400).send({ error: "Audit guest is required" });
        if (!Time_stamp) return res.status(400).send({ error: "Timestamp is required" });
        if (!Affectedentity) return res.status(400).send({ error: "Affected entity is required" });
        if (!details || details.trim() === "") return res.status(400).send({ error: "Details are required" });
        
        const duplicateAudit = await Audit.findOne({
            Audit_guest: Audit_guest,
            Action: Action,
            Affectedentity: Affectedentity,
            details: details.toLowerCase(),
        });

        if (duplicateAudit) {
            return res.status(400).send({ error: "Duplicate audit entry detected" });
        }

        const newAuditData = await Audit.create({
            Action,
            Audit_guest,
            Time_stamp: new Date(Time_stamp), 
            Affectedentity,
            details: details.toLowerCase(),
        });

        return res.status(201).send({
            message: "Audit created successfully",
            Audit: newAuditData,
        });
    } catch (error) {
        console.error("Error creating Audit:", error.message);
        return res.status(500).send({ error: "Internal server error" });
    }
}

//HTTP DELETE
//API : http://localhost:5000/auditdelete/

async function auditdeleterecord(req, res) {
    const auditdelete = req.params.id; await Audit.deleteOne({ _id: auditdelete });
    return res.status(200).send({ "SUCESS": "AUDITLOG DELETE RECORD SUCESS" });

}

//HTTP PUT
//API : http://localhost:5000/auditget/6757c5bb9ed16f24e9bba1fa

async function Auditupadterecord(req, res) {

    try {
        const updateauditrecord = req.params.Audit_guest;
        const auditdata = await Audit.findOne({ Audit_guest: updateauditrecord });
        if (!auditdata) {
            return res.status(404).send({ "ERROR": "AUDIT DATA IS NOT FOUND" });
        }
        const { Action, Audit_guest, Time_stamp, Affectedentity, details } = req.body;

        if (!Action) return res.status(400).send({ error: "Action is required" });
        if (!Audit_guest) return res.status(400).send({ error: "Audit guest is required" });
        if (!Time_stamp) return res.status(400).send({ error: "Timestamp is required" });
        if (!Affectedentity) return res.status(400).send({ error: "Affected entity is required" });
        if (!details || details.trim() === "") return res.status(400).send({ error: "Details are required" });

        // Update AUDITLOG data
        const updateaudit = await Audit.updateOne(
            { Audit_guest: updateauditrecord },
            {
                $set: {
                    Action: Action,
                    Audit_guest: Audit_guest,
                    Time_stamp: Time_stamp,
                    Affectedentity: Affectedentity,
                    details: details,
                },
            }
        );

        if (updateaudit.matchedCount > 0) {
            console.log("Auditlog updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "AUDITLOG IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE AUDITLOG:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}

module.exports = { auditpage, auditsinglepage, auditcreate, auditdeleterecord, Auditupadterecord};
