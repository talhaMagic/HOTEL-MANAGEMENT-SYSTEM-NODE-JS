const Invoice = require('../Modules/invoice'); // Adjust path to your model

//HTTP GET
//API : http://localhost:5000/invoiceget
async function Invoicepage(req, res) {
    const Invoicealldata = await Invoice.find();
    return res.status(201).send(Invoicealldata);
}

//HTTP POST
//API : http://localhost:5000/invoicepost
async function Invoicecreate(req, res) {
    try {
        const { billingid, guestid, detail } = req.body;

        if (!billingid) return res.status(400).send({ ERROR: "BILLING ID IS NOT FOUND" });
        if (!guestid) return res.status(400).send({ ERROR: "GUEST ID IS NOT FOUND" });
        if (!detail) return res.status(400).send({ ERROR: "DETAIL IS NOT FOUND" });

        const existingInvoice = await Invoice.findOne({ Billing_id: billingid });
        if (existingInvoice) return res.status(400).send({ ERROR: "BILLING ID ALREADY EXISTS" });

        const newInvoice = await Invoice.create({ Billing_id: billingid, guest_id: guestid, details: detail });

        return res.status(201).send({ SUCCESS: "INVOICE CREATED SUCCESSFULLY", invoice: newInvoice });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ ERROR: "SERVER INTERNAL ERROR" });
    }
}

//HTTP DELETE
//API : http://localhost:5000/roomdelete/:id

async function deleterecordinvoice(req, res) {
    const invoicedelete = req.params.id; await Invoice.deleteOne({ _id: invoicedelete });
    return res.status(200).send({ "SUCESS": "INVOICE DELETE RECORD SUCESS" });

}

//HTTP PUT
//API : http://localhost:5000/invoiceget/675be928795f85f3d6a2704e

async function invoiceupadterecord(req, res) {

    try {

        const updateinvoice = req.params.Billing_id
        ;
        const invoicedata = await Invoice.findOne({ Billing_id: updateinvoice });
        if (!invoicedata) {
            return res.status(404).send({ "ERROR": "INVOICE IS NOT FOUND" });
        }

        const { billingid, guestid, detail } = req.body;

        if (!billingid) return res.status(400).send({ ERROR: "BILLING ID IS NOT FOUND" });
        if (!guestid) return res.status(400).send({ ERROR: "GUEST ID IS NOT FOUND" });
        if (!detail) return res.status(400).send({ ERROR: "DETAIL IS NOT FOUND" });


        // Update Romms data
        const updateInvoice = await Invoice.updateOne(
            { Billing_id: updateinvoice },
            {
                $set: {
                    Billing_id:billingid,
                    guest_id: guestid,
                    details: detail,
                },
            }
        );

        if (updateInvoice.matchedCount > 0) {
            console.log("Invoice updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "Invoice IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE INVOICE:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}


//HTTP GET
// http://localhost:5000/invoiceget/67616e26645fdaac502d7caa
 const singleinvoicerecord = async (req, res) => {
    try {
        const { id } = req.params;

        // Fetch the invoice and populate necessary fields
        const invoicesingle = await Invoice.findById(id)
            .populate({
                path: "Billing_id", // Populating the Billing_id
                select: "reservation_id billing_amount service payment_status",
            })
            .populate({
                path: "guest_id", // Populating the guest_id directly
                select: "UserName UserEmail Room_status Room_description",
                populate: {
                    path: "role", // Populating role inside guest_id
                    select: "RoleName RoleStatus",
                },
            });

        if (!invoicesingle) {
            return res.status(404).json({ success: false, message: "Invoice not found" });
        }

        return res.status(200).json({ success: true, data: invoicesingle });
    } catch (error) {
        console.error("Error fetching Invoice:", error);
        return res.status(500).json({ success: false, message: "Error fetching Invoice", error: error.message });
    }
};



module.exports = { Invoicepage, Invoicecreate ,deleterecordinvoice,invoiceupadterecord,singleinvoicerecord};
