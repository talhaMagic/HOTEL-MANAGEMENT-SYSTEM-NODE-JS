

const Maintenace = require('../Modules/Maintenace');


//HTTP METHOD GET
//API : http://localhost:5000/Maintenaceget

async function Maintenacepage(req,res){

   const Allmaintenacedata = await Maintenace.find();
    return res.status(201).send(Allmaintenacedata);

}

//HTTP METHOD POST
//API : http://localhost:5000/Maintenacepost

async function Maintencecreate(req, res) {
    try {
        const { roomid, repoetedguestid, describe, mstatus, resolution_date } = req.body;

        // Validate input
        if (!roomid) return res.status(400).send({ "ERROR": "ROOM ID IS NOT FOUND" });
        if (!repoetedguestid) return res.status(400).send({ "ERROR": "REPORTED GUEST ID IS NOT FOUND" });
        if (!describe) return res.status(400).send({ "ERROR": "DESCRIPTION IS NOT FOUND" });
        if (!mstatus) return res.status(400).send({ "ERROR": "STATUS IS NOT FOUND" });
        if (!resolution_date) return res.status(400).send({ "ERROR": "RESOLUTION DATE IS NOT FOUND" });

        // Check for existing maintenance record
        const existingMaintenance = await Maintenace.findOne({ room_id: roomid });
        if (existingMaintenance) {
            return res.status(400).send({ "ERROR": "MAINTENANCE IS ALREADY TAKEN, TRY AGAIN" });
        }

        // Create a new maintenance record
        const newMaintenance = await Maintenace.create({
            room_id: roomid,
            reported_guest_id: repoetedguestid,
            description: describe, // Corrected field name
            status: mstatus,
            resolution_date: resolution_date, // Corrected field name
        });

        return res.status(201).send({ message: "Maintenance created successfully", Maintenance: newMaintenance });
    } catch (error) {
        console.error("Error creating Maintenance:", error.message);
        return res.status(500).send({ error: "SERVER INTERNAL ERROR" });
    }
}

//HTTP DELETE
//API : http://localhost:5000/Maintenacepost/6762a7ca5a7e2b25e8276123

async function maintencedeleterecord(req, res) {
    const maintencedelete = req.params.id; await Maintenace.deleteOne({ _id: maintencedelete });
    return res.status(200).send({ "SUCESS": "Maintenace DELETE RECORD SUCESS" });

}

//HTTP PUT
//API : http://localhost:5000/Maintenaceget/

async function maintenceupadterecord(req, res) {
    try {
        const updatemaintenace = req.params.room_id;
        const maintenacedata = await Maintenace.findOne({ room_id: updatemaintenace });
        if (!maintenacedata) {
            return res.status(404).send({ "ERROR": "MAINTENANCE IS NOT FOUND" });
        }
        const { roomid, repoetedguestid, describe, mstatus, resolution_date } = req.body;

        // Validate input
        if (!roomid) return res.status(400).send({ "ERROR": "ROOM ID IS NOT FOUND" });
        if (!repoetedguestid) return res.status(400).send({ "ERROR": "REPORTED GUEST ID IS NOT FOUND" });
        if (!describe) return res.status(400).send({ "ERROR": "DESCRIPTION IS NOT FOUND" });
        if (!mstatus) return res.status(400).send({ "ERROR": "STATUS IS NOT FOUND" });
        if (!resolution_date) return res.status(400).send({ "ERROR": "RESOLUTION DATE IS NOT FOUND" });

        // Update Maintenance data
        const updatemainten = await Maintenace.updateOne(
            { room_id: updatemaintenace },
            {
                $set: {
                    room_id: roomid,
                    reported_guest_id: repoetedguestid,
                    description: describe,
                    status: mstatus, // Fixed statusbar to mstatus
                    resolution_date: resolution_date,
                },
            }
        );

        if (updatemainten.matchedCount > 0) {
            console.log("Maintenance updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "MAINTENANCE IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPDATE MAINTENANCE:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}

//HTTP METHOD GET
//API : http://localhost:5000/Maintenaceget/67639e6cfea8ea459bfbf651
const maintenacesinglerecord = async (req, res) => {
    try {
        const { id } = req.params;

        const maintenacesingle = await Maintenace.findById(id)
            .populate({
                path: "room_id",
                select: "Room_number Room_type Room_price Room_status Room_description",
                populate: {
                    path: "Room_type", 
                    select: "type_name description base_price",
                },
            })
            .populate({
                path: "reported_guest_id",
                select: "UserName UserEmail UserPassword role staffrole",
                populate: [
                    {
                        path: "role",
                        select: "role_name", 
                    }, 
                    {
                        path: "staffrole",
                        select: "staff_Role Status",
                    },
                ],
            });

        if (!maintenacesingle) {
            return res.status(404).json({ success: false, message: "Maintenance not found" });
        }

        return res.status(200).json({ success: true, data: maintenacesingle });
    } catch (error) {
        console.error("Error fetching Maintenance:", error);
        return res.status(500).json({ success: false, message: "Error fetching Maintenance", error: error.message });
    }
};


module.exports = {Maintenacepage,Maintencecreate,maintencedeleterecord,maintenceupadterecord,maintenacesinglerecord}