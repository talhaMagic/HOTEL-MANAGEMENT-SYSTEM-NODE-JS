const { Feedback } = require("../Modules/Feedback");


// HTTP METHOD GET
// API: http://localhost:5000/feedbackget
async function Feedbackpage(req, res) {
    try {
        const allFeedbackData = await Feedback.find();
        return res.status(200).send(allFeedbackData);
    } catch (error) {
        console.error("Error Fetching Feedback:", error.message);
        return res.status(500).send({ error: "Internal Server Error" });
    }
}

// HTTP METHOD POST
// API: http://localhost:5000/feedbackpost
async function Feedbackcreate(req, res) {
    try {
        const { guestid, reservationid, rating, comments } = req.body;

        // Input validation
        if (!guestid) return res.status(400).send({ error: "GUEST ID IS REQUIRED" });
        if (!reservationid) return res.status(400).send({ error: "RESERVATION ID IS REQUIRED" });
        if (!rating) return res.status(400).send({ error: "RATING IS REQUIRED" });
        if (!comments) return res.status(400).send({ error: "COMMENTS ARE REQUIRED" });

        // Check if feedback already exists for the guest
        const existingFeedback = await Feedback.findOne({ FD_guest_id: guestid });
        if (existingFeedback) {
            return res.status(400).send({ error: "FEEDBACK FOR THIS GUEST ALREADY EXISTS" });
        }

        // Create new feedback
        const newFeedback = await Feedback.create({
            FD_guest_id: guestid,
            FD_reservation_id: reservationid,
            FD_rating: rating,
            FD_comment: comments.toLowerCase(),
        });

        return res.status(201).send({ message: "Feedback created successfully", Feedback: newFeedback });
    } catch (error) {
        console.error("Error Creating Feedback:", error.message);
        return res.status(500).send({ error: "Internal Server Error" });
    }
}

//HTTP DELETE
//API : http://localhost:5000/feedbackdelete/675ff1c8ca8490973b5981d9

async function feedbackdeleterecord(req, res) {
    const feedbackdelete = req.params.id; await Feedback.deleteOne({ _id: feedbackdelete });
    return res.status(200).send({ "SUCESS": "FEEDBACK DELETE RECORD SUCESS" });

}

//HTTP PUT
//API : http://localhost:5000/feedbackget/6757c5bb9ed16f24e9bba1fa

async function feddbackupadterecord(req, res) {

    try {

        const feedbackrecordupadte = req.params.FD_guest_id;
        const feedbackdata = await Feedback.findOne({ FD_guest_id: feedbackrecordupadte });
        if (!feedbackdata) {
            return res.status(404).send({ "ERROR": "FEEDBACK IS NOT FOUND" });
        }

        const { guestid, reservationid, rating, comments } = req.body;

        // Input validation
        if (!guestid) return res.status(400).send({ error: "GUEST ID IS REQUIRED" });
        if (!reservationid) return res.status(400).send({ error: "RESERVATION ID IS REQUIRED" });
        if (!rating) return res.status(400).send({ error: "RATING IS REQUIRED" });
        if (!comments) return res.status(400).send({ error: "COMMENTS ARE REQUIRED" });

        // Update Romms data
        const updatefeedback = await Feedback.updateOne(
            { FD_guest_id: feedbackrecordupadte },
            {
                $set: {
                    FD_guest_id: guestid,
                    FD_reservation_id: reservationid,
                    FD_rating: rating,
                    FD_comment: comments,
                },
            }
        );

        if (updatefeedback.matchedCount > 0) {
            console.log("Feedback updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "FEEDBACK IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE FEEDBACK:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}

//HTTP GET
//API : http://localhost:5000/feedbackget/67616ccf645fdaac502d7ca1

const feedbacksinglerecord = async (req, res) => {
    try {
        const { id } = req.params;

        const Feedbacktypesingle = await Feedback.findById(id)
            .populate({
                path: "FD_guest_id",
                select: "UserName UserEmail role",
                populate: {
                    path: "role",
                    select: "RoleName RoleStatus",
                },
            })
            .populate({
                path: "FD_reservation_id",
                select: "room_id check_in check_out status",
                populate: [
                    {
                        path: "room_id",
                        select: "Room_number Room_price Room_status Room_description Room_type",
                        populate: {
                            path: "Room_type",
                            select: "type_name description base_price",
                        },
                    },
                ],
            });

        if (!Feedbacktypesingle) {
            return res.status(404).json({
                success: false,
                message: "Feedback record not found",
            });
        }

        return res.status(200).json({
            success: true,
            data: Feedbacktypesingle,
        });
    } catch (error) {
        console.error("Error fetching feedback:", error.message);
        return res.status(500).json({
            success: false,
            message: "Error fetching feedback",
            error: error.message,
        });
    }
};



module.exports = { Feedbackpage, Feedbackcreate, feedbackdeleterecord, feddbackupadterecord, feedbacksinglerecord };
