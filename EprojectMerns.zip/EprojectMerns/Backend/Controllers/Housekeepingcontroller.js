
const { Housekeep } = require("../Modules/Housekeeping");

//HTTP METHOD GET
//API : http://localhost:5000/Housekeepget

async function Housepage(req,res){

   const AllHousekeepdata = await Housekeep.find();
    return res.status(201).send(AllHousekeepdata);

}

//HTTP METHOD POST
//API : http://localhost:5000/Housekeeppost
async function Housekeepcreate(req, res) {
   try {
       const { roomid, assignedstaff, housekeepstatus, taskdates } = req.body;

       if (!roomid) return res.status(400).send({ "ERROR": "ROOM ID IS NOT FOUND" });
       if (!assignedstaff) return res.status(400).send({ "ERROR": "ASSIGNED STAFF IS NOT FOUND" });
       if (!housekeepstatus) return res.status(400).send({ "ERROR": "HOUSE KEEPING STATUS IS NOT FOUND" });
       if (!taskdates) return res.status(400).send({ "ERROR": "TASK DATE IS NOT FOUND" });


       const newhousekeepdata = await Housekeep.create({
           room_id: roomid,
           assigned_staff: assignedstaff,
           status: housekeepstatus,
           taskdate: taskdates, 
       });

       return res.status(201).send({ message: "House Keep created successfully", Housekeep: newhousekeepdata });
   } catch (error) {
       console.error("Error creating House keep:", error.message);
       return res.status(500).send({ error: "SERVER INTERNAL ERROR" });
   }
}

//HTTP DELETE
//API : http://localhost:5000/Housekeepdelete/676411fad6ad54ba13f1bf20

async function housekeepdeleterecord(req, res) {
    const Housekeepdelete = req.params.id; await Housekeep.deleteOne({ _id: Housekeepdelete });
    return res.status(200).send({ "SUCESS": "HOUSE KEEPING DELETE RECORD SUCESS" });

}

//HTTP METHOD PUT
//API : http://localhost:5000/Housekeepget/676168a5645fdaac502d7c8e

async function Housekeepupadterecord(req, res) {

    try {

        const updateHousekeep = req.params.assigned_staff;
        const Housekeepdata = await Housekeep.findOne({ assigned_staff: updateHousekeep });
        if (!Housekeepdata) {
            return res.status(404).send({ "ERROR": "HOUSE KEEP IS NOT FOUND" });
        }

        const { roomid, assignedstaff, housekeepstatus, taskdates } = req.body;

        if (!roomid) return res.status(400).send({ "ERROR": "ROOM ID IS NOT FOUND" });
        if (!assignedstaff) return res.status(400).send({ "ERROR": "ASSIGNED STAFF IS NOT FOUND" });
        if (!housekeepstatus) return res.status(400).send({ "ERROR": "HOUSE KEEPING STATUS IS NOT FOUND" });
        if (!taskdates) return res.status(400).send({ "ERROR": "TASK DATE IS NOT FOUND" });

        // Update Housekeep data
        const updateHousekeepdata = await Housekeep.updateOne(
            { assigned_staff: updateHousekeep },
            {
                $set: {
                    room_id: roomid,
                    assigned_staff: assignedstaff,
                    status: housekeepstatus,
                    taskdate: taskdates,
                },
            }
        );

        if (updateHousekeepdata.matchedCount > 0) {
            console.log("Housekeep updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "HOUSEKEEP IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE HOUSEKEEP:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}

//HTTP METHOD GET
//API : http://localhost:5000/Housekeepget/676411fad6ad54ba13f1bf20

const getSingleHousekeepRecord = async (req, res) => {
    try {
        const { id } = req.params;

        const housekeepRecord = await Housekeep.findById(id)
            .populate({
                path: "room_id", 
                select: "Room_number Room_type Room_price Room_status Room_description",
                populate: {
                    path: "Room_type", 
                    select: "type_name description base_price",
                },
            })
            .populate({
                path: "assigned_staff", 
                select: "UserName UserEmail UserPassword role staffrole",
                populate: [
                    {
                        path: "role", 
                        select: "role_name",
                    },
                    {
                        path: "staffrole", 
                        select: "staff_Role Status",
                    },
                ],
            });

        if (!housekeepRecord) {
            return res.status(404).json({ success: false, message: "Housekeeping record not found" });
        }

        return res.status(200).json({ success: true, data: housekeepRecord });
    } catch (error) {
        console.error("Error fetching Housekeeping record:", error);
        return res.status(500).json({
            success: false,
            message: "Error fetching Housekeeping record",
            error: error.message,
        });
    }
};

module.exports = {Housepage,Housekeepcreate,housekeepdeleterecord,Housekeepupadterecord,getSingleHousekeepRecord }