
const bcrypt = require('bcrypt');
const { User } = require("../Modules/Userregister");

//HTTP METHOD GET
//API : http://localhost:5000/registergetpage

async function userpage(req,res){

   const Allregisterdata = await User.find();
    return res.status(201).send(Allregisterdata);

}

//HTTP METHOD POST
//API : http://localhost:5000/registercreate
async function usercreate(req, res) {
   try {
       const { username, useremail, userpassword, rolesall, staffrole } = req.body;

       if (!username) return res.status(400).send({ "ERROR": "USER NAME IS NOT FOUND" });
       if (!useremail) return res.status(400).send({ "ERROR": "USER EMAIL IS NOT FOUND" });
       if (!userpassword) return res.status(400).send({ "ERROR": "USER PASSWORD IS NOT FOUND" });
       if (!rolesall) return res.status(400).send({ "ERROR": "ROLES IS NOT FOUND" });

       const usernameregex = /^[A-Za-z]+$/;
       const useremailregex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.(com)$/;
       const userpasswordregex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

       if (!usernameregex.test(username)) {
           return res.status(400).send({ "ERROR": "EXAMPLE: magic123, Magic123, magic_magic, Magic! THIS DATA ARE NOT ALLOWED" });
       }

       if (!useremailregex.test(useremail)) {
           return res.status(400).send({ "ERROR": "EXAMPLE: user@domain.org, user@domain, user@domain.co THIS TYPE DATA NOT ALLOWED" });
       }

       if (!userpasswordregex.test(userpassword)) {
           return res.status(400).send({ "ERROR": "EXAMPLE: weakpass, 12345678, WEEK PASSWORD NOT ALLOWED" });
       }

       const register = await User.findOne({ UserName: username.toLowerCase() });
       if (register) {
           return res.status(400).send({ "ERROR": "USER IS ALREADY TAKEN TRY AGAIN" });
       }

       const securepasswordhash = await bcrypt.hash(userpassword, 14);

       const newyuser = await User.create({
           UserName: username.toLowerCase(),
           UserEmail: useremail,
           UserPassword: securepasswordhash,
           role: rolesall,
           staffrole: staffrole, 
       });

       return res.status(201).send({ message: "User created successfully", User: newyuser });
   } catch (error) {
       console.error("Error creating user:", error.message);
       return res.status(500).send({ error: "SERVER INTERNAL ERROR" });
   }
}

module.exports = {userpage,usercreate}