
const { checkin } = require("../Modules/Checkinout");

//HTTP METHOD GET
//API : http://localhost:5000/checkinoutget

async function checkinoutpage(req, res) {

    const checkindata = await checkin.find();
    return res.status(201).send(checkindata);

}

// HTTP METHOD POST
// API : http://localhost:5000/checkinoutpost

async function checkinoutCreate(req, res) {
    try {
        const { reservationid, checkint, checkout, keyissu, billingid } = req.body;

        // Validate input
        if (!reservationid) return res.status(400).send({ error: "Reservation ID is required" });
        if (!checkint) return res.status(400).send({ error: "Check-in time is required" });
        if (!checkout) return res.status(400).send({ error: "Check-out time is required" });
        if (!keyissu) return res.status(400).send({ error: "Key issued information is required" });
        if (!billingid) return res.status(400).send({ error: "Billing ID is required" });

        // Check for duplicate check-in/out entry
        const existingCheckinout = await checkin.findOne({ Reservation_id: reservationid });
        if (existingCheckinout) {
            return res.status(400).send({ error: "Check-in/out already exists for this reservation" });
        }

        // Create new check-in/out
        const newCheckinout = await checkin.create({
            Reservation_id: reservationid,
            checkintime: checkint,
            checkouttime: checkout,
            keyissued: keyissu,
            Billing_id: billingid,
        });

        return res.status(201).send({ message: "Check-in/out created successfully", checkin: newCheckinout });
    } catch (error) {
        console.error("Error creating check-in/out:", error.message);
        return res.status(500).send({ error: "Internal Server Error" });
    }
}

// HTTP METHOD DELETE
// API : http://localhost:5000/checkinoutdelete/676259ba77fd25ccd22b445f

async function Deletecheckinout(req, res) {

    const deletecheckinout = req.params.id;
    await checkin.deleteOne({ _id: deletecheckinout });

    return res.status(201).send({ "SUCESS": "DELETE CHECKIN OUT IS SUCESS" });

}

//HTTP PUT
//API : http://localhost:5000/checkinoutget/67616b7e645fdaac502d7c97

async function checkinoutupadterecord(req, res) {

    try {

        const updatecheckinoutdata = req.params.Reservation_id;
        const checkinoutdata = await checkin.findOne({ Reservation_id: updatecheckinoutdata });
        if (!checkinoutdata) {
            return res.status(404).send({ "ERROR": "CHECKIN OUT IS NOT FOUND" });
        }

        const { reservationid, checkint, checkout, keyissu, billingid } = req.body;

        // Validate input
        if (!reservationid) return res.status(400).send({ error: "Reservation ID is required" });
        if (!checkint) return res.status(400).send({ error: "Check-in time is required" });
        if (!checkout) return res.status(400).send({ error: "Check-out time is required" });
        if (!keyissu) return res.status(400).send({ error: "Key issued information is required" });
        if (!billingid) return res.status(400).send({ error: "Billing ID is required" });

        // Update Romms data
        const updatecheckinoutrecords = await checkin.updateOne(
            { Reservation_id: updatecheckinoutdata },
            {
                $set: {
                    Reservation_id: reservationid,
                    checkint: checkint,
                    checkouttime: checkout,
                    keyissued: keyissu,
                    Billing_id: billingid,
                },
            }
        );

        if (updatecheckinoutrecords.matchedCount > 0) {
            console.log("Checkinout updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "CHECKINOUT IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE CHECKINOUT:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}

//HTTP GET
// http://localhost:5000/checkinoutget/676259ba77fd25ccd22b445f

const checkinoutsinglerecord = async (req, res) => {
    try {
        const { id } = req.params;

        const checkinouttypesingle = await checkin.findById(id)
            .populate({
                path: "Reservation_id",
                select: "guest_id room_id check_in check_out status",
                populate: [
                    {
                        path: "guest_id",
                        model: "User",
                        select: "UserName UserEmail UserPassword role",
                        populate: {
                            path: "role",
                            select: "RoleName RoleStatus",
                        },
                    },
                    {
                        path: "room_id",
                        model: "Rooms",
                        select: "Room_number Room_type Room_price Room_status Room_description",
                        populate: {
                            path: "Room_type",
                            select: "type_name description base_price",
                        },
                    },
                ],
            })
            .populate("Billing_id", "reservation_id billing_amount service payment_status");

        if (!checkinouttypesingle) {
            return res.status(404).json({ success: false, message: "Check-in/out record not found" });
        }

        return res.status(200).json({ success: true, data: checkinouttypesingle });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Error fetching check-in/out record", error: error.message });
    }
};

module.exports = { checkinoutpage, checkinoutCreate, Deletecheckinout, checkinoutupadterecord, checkinoutsinglerecord }