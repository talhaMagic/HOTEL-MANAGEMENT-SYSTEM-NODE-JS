
const Reservation = require("../Modules/Reserviation"); // Default export



//HTTP GET
//API : http://localhost:5000/Reservationget
async function Reservationpage(req,res){

   const Reservationalldata = await Reservation.find();
   return res.status(201).send(Reservationalldata);
   

}

//HTTP POST
//API : http://localhost:5000/Reservationpost
async function Reservationcreate(req, res) {
   try {
       const { guestid, roomid, checkin, checkout, statusres } = req.body;

       if (!guestid || !roomid || !checkin || !checkout || !statusres) {
           return res.status(400).send({ "ERROR": "MISSING REQUIRED FIELDS" });
       }

       const existingReservation = await Reservation.findOne({
           guest_id: guestid,
           room_id: roomid,
           check_in: checkin,
       });

       if (existingReservation) {
           return res.status(400).send({ "ERROR": "RESERVATION ALREADY EXISTS" });
       }

       const newReservation = await Reservation.create({
           guest_id: guestid,
           room_id: roomid,
           check_in: checkin,
           check_out: checkout,
           status: statusres,
       });

       return res.status(201).send({ "SUCCESS": "RESERVATION CREATED", reservation: newReservation });
   } catch (error) {
       console.error("Reservationcreate Error:", error.message);
       return res.status(500).send({ "ERROR": "SERVER INTERNAL ERROR" });
   }
}

//HTTP DELETE
//API : http://localhost:5000/Reservationdelete

 async function deletereservation(req, res) {
   const deletereservation = req.params.id; await Reservation.deleteOne({ _id: deletereservation });
   return res.status(200).send({ "SUCESS": "DELETE RESERVATION SUCESS" });

}

//HTTP PUT
//API : http://localhost:5000/Reservationget/confirmed 
// YE STATUS LAST ME OLD RECORD WALA AYGA AGAIN NEW RECORD UPADTE HOGA

async function Reservationupdate(req, res) {

   try{
      const updateReservation = req.params.status;
       const Roomdata = await Reservation.findOne({ status: updateReservation });
       if (!Roomdata) {
           return res.status(404).send({ "ERROR": "ROOM IS NOT FOUND" });
       }

       const { guestid, roomid, staffid, checkin, checkout, statusres } = req.body;

       // Validate required fields
       if (!guestid || !roomid || !staffid || !checkin || !checkout || !statusres) {
           return res.status(400).send({ "ERROR": "MISSING REQUIRED FIELDS" });
       } 

          const UpdateReser = await Reservation.updateOne(
            { status: updateReservation },
            {
                $set: {
                  guest_id: guestid.toLowerCase(),
                  room_id: roomid,
                  staff_id: staffid,
                  check_in: checkin,
                  check_out: checkout,
                  status: statusres,
                },
            }
        );

        if (UpdateReser.matchedCount > 0) {
         console.log("Reservation updated successfully");
         return res.send({ success: true, data: req.body });
     } else {
         return res.status(404).send({ "ERROR": "RESERVATION IS NOT FOUND" });
     }
 } catch (error) {
     console.error("ERROR UPADTE RESERVATION:", error);
     return res.status(500).send({ error: "Internal Server Error", details: error.message });
 }

}

//HTTP GET
//API : http://localhost:5000/Reservationget/67616b7e645fdaac502d7c97

const reservationsinglerecord = async (req, res) => {
   try {
       const { id } = req.params;

       const Reservationtypesingle = await Reservation.findById(id)
       .populate("guest_id", "UserName UserEmail UserPassword role")
       .populate("room_id", "Room_number Room_type Room_price Room_status Room_description");
       

       if (!Reservationtypesingle) {
           return res.status(404).json({ success: false, message: "Reservation type single is not found" });
       }

       return res.status(200).json({ success: true, data: Reservationtypesingle });
   } catch (error) {
       return res.status(500).json({ success: false, message: "Error fetching singlereservation type", error: error.message });
   }
};



module.exports = {Reservationpage,Reservationcreate,deletereservation,Reservationupdate,reservationsinglerecord}