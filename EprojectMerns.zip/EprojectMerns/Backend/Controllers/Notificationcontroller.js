const notification = require('../Modules/Notification'); // Ensure the path is correct

// HTTP GET
// API: http://localhost:5000/notificationget
async function notificationpage(req, res) {
    try {
        const Notifictionalldata = await notification.find();
        return res.status(200).send(Notifictionalldata); // Use 200 for successful GET
    } catch (error) {
        console.error("Error fetching notifications:", error);
        return res.status(500).send({ ERROR: "SERVER INTERNAL ERROR" });
    }
}

// HTTP POST
// API: http://localhost:5000/notifictaionpost
async function notificationcreate(req, res) {
    try {
        const { notificationtyp, notificationmessage, receptionid } = req.body;

        // Validate input
        if (!notificationtyp) return res.status(400).send({ ERROR: "NOTIFICATION TYPE IS REQUIRED" });
        if (!notificationmessage) return res.status(400).send({ ERROR: "NOTIFICATION MESSAGE IS REQUIRED" });
        if (!receptionid) return res.status(400).send({ ERROR: "RECEPTION ID IS REQUIRED" });

        // Check if notification type already exists
        const existingNotification = await notification.findOne({ Notification_type: notificationtyp });
        if (existingNotification) {
            return res.status(400).send({ ERROR: "NOTIFICATION TYPE ALREADY EXISTS" });
        }

        // Create new notification
        const newNotification = new notification({
            Notification_type: notificationtyp,
            Notification_Messsage: notificationmessage,
            Reception_id: receptionid,
        });

        await newNotification.save();

        return res.status(201).send({ SUCCESS: "NOTIFICATION CREATED SUCCESSFULLY" });
    } catch (error) {
        console.error("Error creating notification:", error);
        return res.status(500).send({ ERROR: "SERVER INTERNAL ERROR" });
    }
}

//HTTP DELETE
//API :  http://localhost:5000/notifictaiondelete/675eedf4a594413d6fb78ad2

async function notificationdeleterecord(req, res) {
    const notificationdelete = req.params.id; await notification.deleteOne({ _id: notificationdelete });
    return res.status(200).send({ "SUCESS": "NOTIFICATION DELETE RECORD SUCESS" });
    
}

//HTTP PUT
//API :  http://localhost:5000/notificationget/warning

async function notificationupadterecord(req, res) {

    try {

        const updatenotification = req.params.Notification_type;
        const notificationdata = await notification.findOne({ Notification_type: updatenotification });
        if (!notificationdata) {
            return res.status(404).send({ "ERROR": "NOTIFICATION IS NOT FOUND" });
        }

        const { notificationtyp, notificationmessage, receptionid } = req.body;

        // Validate input
        if (!notificationtyp) return res.status(400).send({ ERROR: "NOTIFICATION TYPE IS REQUIRED" });
        if (!notificationmessage) return res.status(400).send({ ERROR: "NOTIFICATION MESSAGE IS REQUIRED" });
        if (!receptionid) return res.status(400).send({ ERROR: "RECEPTION ID IS REQUIRED" });

        // Update Romms data
        const updatnoti = await notification.updateOne(
            { Notification_type: updatenotification },
            {
                $set: {
                    Notification_type: notificationtyp,
                    Notification_Messsage: notificationmessage,
                    Reception_id: receptionid,
                },
            }
        );

        if (updatnoti.matchedCount > 0) {
            console.log("Notification updated successfully");
            return res.send({ success: true, data: req.body });
        } else {
            return res.status(404).send({ "ERROR": "NOTIFICATION IS NOT FOUND" });
        }
    } catch (error) {
        console.error("ERROR UPADTE ROOMS:", error);
        return res.status(500).send({ error: "Internal Server Error", details: error.message });
    }
}

//HTTP GET
//API :  http://localhost:5000/notificationget/67616c3e645fdaac502d7c9e

const notificationsinglerecord = async (req, res) => {
    try {
        const { id } = req.params;

        const notificationtypesingle = await notification.findById(id)
            .populate({
                path: "Reception_id",
                select: "UserName UserEmail UserPassword role",
                populate: {
                    path: "role", 
                    select: "RoleName RoleStatus",
                },
            });

        if (!notificationtypesingle) {
            return res.status(404).json({ success: false, message: "Notification single is not found" });
        }

        return res.status(200).json({ success: true, data: notificationtypesingle });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Error fetching singlenotification", error: error.message });
    }
};



module.exports = { notificationpage, notificationcreate, notificationdeleterecord, notificationupadterecord, notificationsinglerecord};
