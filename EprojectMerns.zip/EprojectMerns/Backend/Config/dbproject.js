
const mongoose = require("mongoose");

async function ProjectDB(){

  const connectproject = await mongoose.connect(process.env.DB);   

  return console.log("MONGO DB ATLAS IS SUCESS CONNECT");

}

module.exports = {ProjectDB}