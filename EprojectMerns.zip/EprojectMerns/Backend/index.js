
const express = require("express");

const app = express();

const dotenvprojectfile = require("dotenv").config()

app.use(express.urlencoded({ extended: true }));

app.use(express.json());


//---DB CONNECT DATABASE IMPORT---//

const { ProjectDB } = require("./Config/dbproject");


//---USER CONTROLLER IMPORT---//

const { userpage, usercreate } = require("./Controllers/Regiscontroller");

app.route("/registergetpage").get(userpage);
app.route("/registercreate").post(usercreate);

//---ROLES CONTROLLER IMPORT---//

const { Rolepage, Rolecreate, DeleteRoles, updateRoles } = require("./Controllers/Rolecontroller");

app.route("/Roleget").get(Rolepage);
app.route("/Rolepost").post(Rolecreate);
app.route("/Roleget/:id").delete(DeleteRoles);
app.route("/Roleget/:id").put(updateRoles);

//---ROLES CONTROLLER IMPORT---//

const { Roomtypepage, Roomtypecreate, Deleteroomtypedata, Updateroomtype } = require("./Controllers/Roomtypecontroller");

app.route("/roomtypeget").get(Roomtypepage);
app.route("/roomtypepost").post(Roomtypecreate);
app.route("/roomtypedelete/:id").delete(Deleteroomtypedata);
app.route("/roomtypeupdate/:payment_status").put(Updateroomtype);

//---ROOM CONTROLLER IMPORT---//

const { Roompage, Roompcreate, roomdeleterecord, roomupadterecord, roomtypesinglerecord } = require("./Controllers/Rooms");

app.route("/roompage").get(Roompage);
app.route("/roompagepost").post(Roompcreate);
app.route("/roomdelete/:id").delete(roomdeleterecord);
app.route("/roompage/:Room_number").put(roomupadterecord);
app.route("/roompage/:id").get(roomtypesinglerecord);

//---RESERVATION CONTROLLER IMPORT---//

const { Reservationpage, Reservationcreate, deletereservation, Reservationupdate, reservationsinglerecord } = require("./Controllers/Reservitaioncontroller");

app.route("/Reservationget").get(Reservationpage);
app.route("/Reservationpost").post(Reservationcreate);
app.route("/Reservationdelete/:id").delete(deletereservation);
app.route("/Reservationget/:status").put(Reservationupdate);
app.route("/Reservationget/:id").get(reservationsinglerecord);


//---STAFFROLES CONTROLLER IMPORT---//

const {staffcreate, staffupdate, staffget, staffrecorddelete } = require("./Controllers/Staffrolecontroller");

app.route("/staffget").get(staffget);
app.route("/staffpost").post(staffcreate);
app.route("/staffdelete/:id").delete(staffrecorddelete);
app.route("/staffupdate/:staff_Role").put(staffupdate);


//---Billing CONTROLLER IMPORT---//

const { Billingcreate, Billpage, Billingdeleterecord, Billingupadterecord, singlebillingrecord } = require("./Controllers/Billingcontroller");

app.route("/Billingget").get(Billpage);
app.route("/Billingpost").post(Billingcreate);
app.route("/Billindelte/:id").delete(Billingdeleterecord);
app.route("/Billingget/:payment_status").put(Billingupadterecord);
app.route("/Billingget/:id").get(singlebillingrecord);


//---INVOICE CONTROLLER IMPORT---//

const { Invoicepage, Invoicecreate, deleterecordinvoice, invoiceupadterecord, singleinvoicerecord } = require("./Controllers/Invoicecontroller");

app.route("/invoiceget").get(Invoicepage);
app.route("/invoicepost").post(Invoicecreate);
app.route("/invoicedelete/:id").delete(deleterecordinvoice);
app.route("/invoiceget/:Billing_id").put(invoiceupadterecord);
app.route("/invoiceget/:id").get(singleinvoicerecord);

//---NOTIFICATION CONTROLLER IMPORT---//

const { notificationpage, notificationcreate, notificationdeleterecord, notificationupadterecord, notificationsinglerecord} = require("./Controllers/Notificationcontroller");

app.route("/notificationget").get(notificationpage);
app.route("/notifictaionpost").post(notificationcreate);
app.route("/notifictaiondelete/:id").delete(notificationdeleterecord);
app.route("/notificationget/:Notification_type").put(notificationupadterecord);
app.route("/notificationget/:id").get(notificationsinglerecord);

//---FEEDBACK CONTROLLER IMPORT---//

const {Feedbackpage,Feedbackcreate,feedbackdeleterecord,feddbackupadterecord,feedbacksinglerecord} = require("./Controllers/Feedbackcontroller");

app.route("/feedbackget").get(Feedbackpage);
app.route("/feedbackpost").post(Feedbackcreate);
app.route("/feedbackdelete/:id").delete(feedbackdeleterecord);
app.route("/feedbackget/:FD_guest_id").put(feddbackupadterecord);
app.route("/feedbackget/:id").get(feedbacksinglerecord);

//---AUDITLOG CONTROLLER IMPORT---//

const {auditpage,auditsinglepage,auditcreate,auditdeleterecord,Auditupadterecord} = require("./Controllers/Auditcontroller");

app.route("/auditget").get(auditpage);
app.route("/auditget/:id").get(auditsinglepage);
app.route("/auditpost").post(auditcreate);
app.route("/auditdelete/:id").delete(auditdeleterecord);
app.route("/auditget/:Audit_guest").put(Auditupadterecord);

//---CHECKINOUT CONTROLLER IMPORT---//

const {checkinoutpage,checkinoutCreate,Deletecheckinout,checkinoutupadterecord,checkinoutsinglerecord} = require("./Controllers/Checkinout");

app.route("/checkinoutget").get(checkinoutpage);
app.route("/checkinoutpost").post(checkinoutCreate);
app.route("/checkinoutdelete/:id").delete(Deletecheckinout);
app.route("/checkinoutget/:Reservation_id").put(checkinoutupadterecord);
app.route("/checkinoutget/:id").get(checkinoutsinglerecord);

//---Maintence CONTROLLER IMPORT---//

const {Maintenacepage,Maintencecreate,maintencedeleterecord,maintenceupadterecord,maintenacesinglerecord} = require("./Controllers/Maintenace");

app.route("/Maintenaceget").get(Maintenacepage);
app.route("/Maintenacepost").post(Maintencecreate);
app.route("/Maintenacedelete/:id").delete(maintencedeleterecord);
app.route("/Maintenaceget/:room_id").put(maintenceupadterecord);
app.route("/Maintenaceget/:id").get(maintenacesinglerecord);

//---HOUSEKEEP CONTROLLER IMPORT---//

const {Housepage,Housekeepcreate,housekeepdeleterecord,Housekeepupadterecord,getSingleHousekeepRecord } = require("./Controllers/Housekeepingcontroller");

app.route("/Housekeepget").get(Housepage);
app.route("/Housekeeppost").post(Housekeepcreate);
app.route("/Housekeepdelete/:id").delete(housekeepdeleterecord);
app.route("/Housekeepget/:assigned_staff").put(Housekeepupadterecord);
app.route("/Housekeepget/:id").get(getSingleHousekeepRecord);


app.listen(process.env.PORT, function () {

    console.log(`SERVER IS SUCESSFULLY START PORT NUMBER IS ${process.env.PORT}`);
    ProjectDB();
})