const mongoose = require('mongoose');

const AuditlogSchema = new mongoose.Schema({
    Action: {
        type: String,
        required: true,
    },
    Audit_guest: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', 
        required: true,
    },
    Time_stamp: {
        type: String,
        required: true,
    },
    Affectedentity: {
        type: String,
        required: true,
    },
    details: {
        type: String,
        required: true,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const Audit = mongoose.model('Audit', AuditlogSchema);

module.exports = { Audit };
