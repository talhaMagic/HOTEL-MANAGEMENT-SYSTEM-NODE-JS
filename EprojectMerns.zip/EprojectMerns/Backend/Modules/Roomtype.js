const mongoose = require('mongoose');


const RoomtypeSchema = mongoose.Schema({
    type_name: {
        type: String,
        enum: ['single', 'double', 'suite'],
        required: true,
    },
    description: {
        type: String,
        required:true,
    },
     base_price: {
        type: Number,
        required: true,
        
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
    updated_at: {
        type: Date,
        default: Date.now,
    },
});

const Roomtyp = mongoose.model('Roomtyp', RoomtypeSchema);

module.exports = {Roomtyp};
