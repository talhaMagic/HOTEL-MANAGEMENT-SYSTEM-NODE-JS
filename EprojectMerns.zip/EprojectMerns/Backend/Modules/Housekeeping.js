const mongoose = require('mongoose');

const HousekeepingSchema = new mongoose.Schema({
    room_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Rooms', 
        required: true,
    },
    assigned_staff: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', 
        required: true,
    },
    status: {
        type: String,
        required: true,
    },
    taskdate: {
        type: String,
        required: true,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const Housekeep = mongoose.model('Housekeep', HousekeepingSchema);

module.exports = { Housekeep };
