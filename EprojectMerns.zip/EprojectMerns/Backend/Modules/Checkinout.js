const mongoose = require('mongoose');


const CheckinoutSchema = mongoose.Schema({
    Reservation_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Reservation',
        required: true,
    },
    checkintime: {
        type: String,
        required: true,
    },
    checkouttime: {
        type: String,
        required: true,
    },
     keyissued: {
        type: String,
        required: true,
    },
    Billing_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Billing',
        required: true,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const checkin = mongoose.model('checkin', CheckinoutSchema);

module.exports = {checkin};
