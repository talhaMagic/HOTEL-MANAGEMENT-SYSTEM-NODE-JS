const mongoose = require('mongoose');

const NotificationSchema = mongoose.Schema({
    Notification_type: {
        type: String,
        required: true,
    },
    Notification_Messsage: {
        type: String,
        required: true,
    },
    Reception_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const notification = mongoose.model('notification', NotificationSchema);

module.exports = notification; // Correct export
