const mongoose = require('mongoose');

const MaintenceSchema = new mongoose.Schema({
    room_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Rooms',
        required: true,
    },
    reported_guest_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    description: { // Corrected spelling
        type: String,
        required: true,
    },
    status: {
        type: String,
        required: true,
    },
    resolution_date: { // Corrected spelling
        type: String,
        required: true,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const Maintenace = mongoose.model('Maintenace', MaintenceSchema);
module.exports = Maintenace;
