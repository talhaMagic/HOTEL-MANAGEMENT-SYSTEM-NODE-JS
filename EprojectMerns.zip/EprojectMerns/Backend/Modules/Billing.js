const mongoose = require('mongoose');

const BillingSchema = new mongoose.Schema({
    reservation_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Reservation',
        required: true,
    },
    billing_amount: {
        type:String,
        required: true,
    },
    service: {
        type:String,
        required: true,
    },
    payment_status: {
        type:String,
        required: true,  
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
    updated_at: {
        type: Date,
        default: Date.now,
    },
});

const Billing = mongoose.model('Billing', BillingSchema);

// Correctly export the model
module.exports = Billing;
