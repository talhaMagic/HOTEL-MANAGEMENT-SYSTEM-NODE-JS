const mongoose = require('mongoose');

const RoomSchema = new mongoose.Schema({
    Room_number: {
        type: String,
        required: true,
    },
    Room_type: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Roomtyp', 
        required: true,
    },
    Room_price: {
        type: String,
        required: true,
    },
    Room_status: {
        type: String,
        values: ["available", "booked", "occupied"],
        required: true,
    },
    Room_description: {
        type: String,
        required: true,
    },
    
    created_at: {
        type: Date,
        default: Date.now,
    },
    updated_at: {
        type: Date,
        default: Date.now,
    },
});

const Rooms = mongoose.model('Rooms', RoomSchema);  // Make sure this matches with your import

module.exports = { Rooms };
