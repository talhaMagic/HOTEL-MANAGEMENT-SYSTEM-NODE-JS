const mongoose = require("mongoose");

const StaffRolesSchema = new mongoose.Schema({
    staff_Role: {
        type: String,
        required: true,
    },
    Status: {
        type: String,
        enum: ["active", "inactive"],
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
    updated_at: {
        type: Date,
        default: Date.now,
    },
});

const staffrole = mongoose.model("staffrole", StaffRolesSchema);

module.exports = { staffrole };
