const mongoose = require('mongoose');


const RoleSchema = mongoose.Schema({
    RoleName: {
        type: String,
        required: true,
        enum: ['admin', 'guest', 'staff'],
    },
    RoleStatus: {
        type: String,
        enum: ['active', 'inactive'],
        default: 'active',
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
    updated_at: {
        type: Date,
        default: Date.now,
    },
});

const Role = mongoose.model('Role', RoleSchema);

module.exports = {Role};
