const mongoose = require('mongoose');

const InvoiceSchema = new mongoose.Schema({
    Billing_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Billing',
        required: true,
    },
    guest_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    details: {
        type: String,
        required: true,
    },
    created_at: {
        type: Date,
        default: Date.now,
    },
});

const Invoice = mongoose.model('Invoice', InvoiceSchema);
module.exports = Invoice;
